## Usage

```
yarn install
yarn dev

yarn run build

npx next export
```

Please run : yarn run build
