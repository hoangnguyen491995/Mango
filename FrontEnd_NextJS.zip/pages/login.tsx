import { SignIn } from "src/components/Authenticate";

const Login = () => {
  return (
    <>
      <SignIn />
    </>
  );
};

export default Login;
