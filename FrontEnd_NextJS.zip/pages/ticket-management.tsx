import { ClosedTicket } from "src/components/ClosedTicket/ClosedTicket";

const TicketManagement = () => {
  return (
    <>
      <ClosedTicket />
    </>
  );
};

export default TicketManagement;
