type Errors = string[]
