declare namespace MenuGlobal {
  interface MenuItem {
    key: string
    title: string
    desc: string
    pathname: string
  }
}
