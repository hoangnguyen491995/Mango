export const LeftTabTechSalonCenter$ = (state: any) => {
  return state.SalonCenter;
};

export const CreateCharge$ = (state: any) => {
  return state.CreateCharge;
};
export const AddNewBooking$ = (state: any) => {
  return state.AddNewBooking;
};
export const WaitlistBooking$ = (state: any) => {
  return state.Booking;
};
export const isChangeDataTixSalonCenter$ = (state: any) => {

  return state.IsChangeDataTixSalonCenter;
};
export const isChangeDataTechSalonCenter$ = (state: any) => {

  return state.IsChangeDataTechSalonCenter;
};

export const showSelectTechService$ = (state: any) => {
  return state.ShowSelectTechService
}          