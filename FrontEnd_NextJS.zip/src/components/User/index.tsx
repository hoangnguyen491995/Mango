import React, { FC, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";

import Profile from "./Profile";

const User: FC = () => {
  useEffect(() => {}, []);

  return <></>;
};

export default User;
