// @flow
import { Button } from "antd";
import * as React from "react";
type Props = {};
export const index = (props: Props) => {
  return <img src="/assets/imgs/icon-turn-tracker.svg" className="abo"/>;
};
