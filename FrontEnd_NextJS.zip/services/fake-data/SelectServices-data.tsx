export const SelectTypeServicedata = [{ name: "service" }, { name: "product" }];
export const SelectServicesdata = [
  { id: "1", name: "BODY MASSAGE", type: "service" },
  { id: "2", name: "FACICALS", type: "service" },
  { id: "3", name: "MORE", type: "service" },
  { id: "4", name: "MUTIPLE", type: "service" },
  { id: "5", name: "PEDICURE", type: "service" },
  { id: "6", name: "EYELASHED", type: "service" },
  { id: "7", name: "SHELLACE", type: "service" },
  { id: "12", name: "Trà Sữa", type: "product" },
  { id: "13", name: "Nước Suối", type: "product" },
  { id: "14", name: "Nước Chanh", type: "product" },


];
