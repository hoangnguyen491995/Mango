import createWindow from './create-window';

export {
  createWindow,
};
